// =====================================================================
// DASHBOARD — visão geral do painel. Manutenções e Guepar Uso aparecem
// em destaque (são o que precisa de atenção operacional no dia a dia),
// Peças e Fornecedores ficam como cards de apoio, e a lista de alertas
// junta as três origens (peças, Guepar, manutenções) num só lugar.
// =====================================================================
import { state } from './state.js';
import { $, esc } from './utils.js';
import { statusManutencao } from './manutencoes.js';

export function renderDashboard() {
  const { dados } = state;

  const pecasCriticas = dados.pecas.filter(p => p.estoque <= p.min_estoque);
  const gueparCriticos = dados.guepar.filter(g => g.estoque <= g.min_estoque);

  const manuInfo = dados.manutencoes.map(m => ({ ...m, ...statusManutencao(m.validade) }));
  const manuVencidas = manuInfo.filter(m => m.status === 'vencida');
  const manuVencendo = manuInfo.filter(m => m.status === 'vencendo');
  const manuOk = manuInfo.filter(m => m.status === 'no_prazo');

  renderDestaques({ dados, manuVencidas, manuVencendo, manuOk, gueparCriticos });
  renderSecundarios({ dados, pecasCriticas });
  renderAlertas({ pecasCriticas, gueparCriticos, manuVencidas, manuVencendo });
}

// ---------- Chip pequeno de contagem (usado dentro dos cards de destaque) ----------
function chip(cor, texto) {
  const cores = {
    red:    'text-red-400 bg-red-500/10',
    yellow: 'text-yellow-400 bg-yellow-500/10',
    green:  'text-green-400 bg-green-500/10',
    blue:   'text-blue-400 bg-blue-500/10'
  };
  return `<span class="text-xs font-bold px-2.5 py-1 rounded-full ${cores[cor]}">${texto}</span>`;
}

// ---------- Cards principais: Manutenções + Guepar Uso ----------
function renderDestaques({ dados, manuVencidas, manuVencendo, manuOk, gueparCriticos }) {
  const totalManu = dados.manutencoes.length;
  const totalGuepar = dados.guepar.length;
  const gueparSaudavel = totalGuepar - gueparCriticos.length;
  const pctManuOk = totalManu ? Math.round((manuOk.length / totalManu) * 100) : 100;
  const pctGueparOk = totalGuepar ? Math.round((gueparSaudavel / totalGuepar) * 100) : 100;

  const cardManutencao = `
    <div class="relative overflow-hidden bg-gradient-to-br from-tech-800 to-tech-800 border border-orange-500/30 rounded-2xl p-6 md:p-7 shadow-xl">
      <div class="absolute -top-6 -right-6 opacity-[0.07]"><i class="ph ph-calendar-check text-[160px]"></i></div>
      <div class="relative">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-11 h-11 rounded-xl bg-orange-500/15 flex items-center justify-center shrink-0">
              <i class="ph ph-calendar-check text-2xl text-orange-400"></i>
            </span>
            <div>
              <p class="text-xs uppercase tracking-wider text-orange-400 font-bold">Principal</p>
              <h3 class="text-lg font-bold text-gray-100">Manutenções</h3>
            </div>
          </div>
          <button data-tab="manutencoes" class="menu-atalho text-xs font-bold text-gray-300 hover:text-tech-accent bg-tech-700/60 hover:bg-tech-700 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1">
            Ver todas <i class="ph ph-arrow-right"></i>
          </button>
        </div>
        <p class="text-5xl font-bold mb-1">${totalManu} <span class="text-base font-normal text-gray-400">agendadas</span></p>
        <div class="w-full h-1.5 bg-tech-700 rounded-full overflow-hidden mb-4 mt-3">
          <div class="h-full bg-orange-400 rounded-full transition-all" style="width:${pctManuOk}%"></div>
        </div>
        <div class="flex flex-wrap gap-2">
          ${manuVencidas.length ? chip('red', `${manuVencidas.length} vencida${manuVencidas.length > 1 ? 's' : ''}`) : ''}
          ${manuVencendo.length ? chip('yellow', `${manuVencendo.length} vencendo em 7 dias`) : ''}
          ${chip('green', `${manuOk.length} no prazo`)}
        </div>
      </div>
    </div>`;

  const cardGuepar = `
    <div class="relative overflow-hidden bg-gradient-to-br from-tech-800 to-tech-800 border border-tech-accent/30 rounded-2xl p-6 md:p-7 shadow-xl">
      <div class="absolute -top-6 -right-6 opacity-[0.07]"><i class="ph ph-wrench text-[160px]"></i></div>
      <div class="relative">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-11 h-11 rounded-xl bg-tech-accent/15 flex items-center justify-center shrink-0">
              <i class="ph ph-wrench text-2xl text-tech-accent"></i>
            </span>
            <div>
              <p class="text-xs uppercase tracking-wider text-tech-accent font-bold">Principal</p>
              <h3 class="text-lg font-bold text-gray-100">Guepar uso</h3>
            </div>
          </div>
          <button data-tab="guepar" class="menu-atalho text-xs font-bold text-gray-300 hover:text-tech-accent bg-tech-700/60 hover:bg-tech-700 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1">
            Ver todos <i class="ph ph-arrow-right"></i>
          </button>
        </div>
        <p class="text-5xl font-bold mb-1">${totalGuepar} <span class="text-base font-normal text-gray-400">itens</span></p>
        <div class="w-full h-1.5 bg-tech-700 rounded-full overflow-hidden mb-4 mt-3">
          <div class="h-full bg-tech-accent rounded-full transition-all" style="width:${pctGueparOk}%"></div>
        </div>
        <div class="flex flex-wrap gap-2">
          ${gueparCriticos.length ? chip('yellow', `${gueparCriticos.length} precisam de reposição`) : chip('green', 'Estoque saudável')}
          ${chip('blue', `${gueparSaudavel} ok`)}
        </div>
      </div>
    </div>`;

  $('cards-destaque').innerHTML = cardManutencao + cardGuepar;

  // Atalhos dos cards de destaque levam para a aba correspondente.
  $('cards-destaque').querySelectorAll('.menu-atalho').forEach(b => {
    b.addEventListener('click', () => document.querySelector(`.menu-btn[data-tab="${b.dataset.tab}"]`)?.click());
  });
}

// ---------- Cards secundários: Peças + Fornecedores ----------
function renderSecundarios({ dados, pecasCriticas }) {
  const cardSecundario = (icone, titulo, valor, unidade, rodape, tab) => `
    <div class="bg-tech-800 p-5 rounded-xl border border-tech-700 shadow-lg relative overflow-hidden">
      <div class="absolute top-0 right-0 p-3 opacity-10"><i class="ph ph-${icone} text-6xl"></i></div>
      <div class="relative flex items-center justify-between mb-2">
        <div class="flex items-center gap-2"><i class="ph ph-${icone} text-xl text-gray-400"></i><h3 class="text-sm font-bold text-gray-400">${titulo}</h3></div>
        <button data-tab="${tab}" class="menu-atalho text-gray-500 hover:text-tech-accent"><i class="ph ph-arrow-right"></i></button>
      </div>
      <p class="text-3xl font-bold mb-2">${valor} <span class="text-sm font-normal text-gray-400">${unidade}</span></p>
      ${rodape}
    </div>`;

  const ok = t => `<p class="text-green-400 text-xs font-bold bg-green-500/10 inline-block px-2 py-1 rounded"><i class="ph ph-check-circle mr-1"></i>${t}</p>`;
  const alertaVermelho = t => `<p class="text-red-400 text-xs font-bold bg-red-500/10 inline-block px-2 py-1 rounded"><i class="ph ph-warning mr-1"></i>${t}</p>`;

  $('cards-secundarios').innerHTML =
    cardSecundario('cpu', 'Peças do robô', dados.pecas.length, 'itens',
      pecasCriticas.length ? alertaVermelho(`${pecasCriticas.length} em alerta ou falta`) : ok('Estoque saudável'), 'pecas') +
    cardSecundario('users', 'Fornecedores', dados.fornecedores.length, 'empresas',
      `<p class="text-blue-400 text-xs font-bold bg-blue-500/10 inline-block px-2 py-1 rounded"><i class="ph ph-info mr-1"></i> Contatos ativos</p>`, 'fornecedores');

  $('cards-secundarios').querySelectorAll('.menu-atalho').forEach(b => {
    b.addEventListener('click', () => document.querySelector(`.menu-btn[data-tab="${b.dataset.tab}"]`)?.click());
  });
}

// ---------- Lista unificada de prioridades (peças + Guepar + manutenções) ----------
function renderAlertas({ pecasCriticas, gueparCriticos, manuVencidas, manuVencendo }) {
  const itensEstoque = [...pecasCriticas, ...gueparCriticos].map(i => ({
    tipo: 'estoque',
    texto: esc(i.nome),
    detalhe: `${i.estoque} em estoque · mínimo ${i.min_estoque}`
  }));
  const itensManu = [...manuVencidas, ...manuVencendo].map(m => ({
    tipo: 'manutencao',
    texto: esc(m.nome),
    detalhe: m.status === 'vencida' ? 'Manutenção vencida' : `Vence em ${m.diffDias} dia${m.diffDias === 1 ? '' : 's'}`
  }));

  const todos = [...itensManu, ...itensEstoque];
  $('alertas-dashboard').innerHTML = todos.length ? `
    <div class="bg-tech-800 border border-yellow-500/40 rounded-lg p-6">
      <h3 class="font-bold text-yellow-400 mb-3 flex items-center gap-2"><i class="ph ph-warning-circle text-xl"></i> Repor / verificar com prioridade</h3>
      <ul class="space-y-2">${todos.map(i => `
        <li class="flex justify-between items-center border-b border-tech-700 pb-2 last:border-0">
          <span class="flex items-center gap-2">
            <i class="ph ${i.tipo === 'manutencao' ? 'ph-calendar-check text-orange-400' : 'ph-package text-tech-accent'}"></i>
            ${i.texto}
          </span>
          <span class="text-gray-400 text-sm">${i.detalhe}</span>
        </li>`).join('')}</ul>
    </div>` : `
    <div class="bg-tech-800 border border-green-500/30 rounded-lg p-6 flex items-center gap-3">
      <i class="ph ph-check-circle text-2xl text-green-400"></i>
      <p class="text-gray-300">Tudo em dia: sem faltas de estoque e sem manutenções vencendo.</p>
    </div>`;
}
