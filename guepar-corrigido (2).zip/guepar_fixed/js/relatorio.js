// =====================================================================
// RELATÓRIO — junta as quatro tabelas (peças, Guepar, fornecedores,
// manutenções) num documento único, aberto em nova aba, já formatado
// para impressão / "Salvar como PDF" pelo próprio navegador.
// =====================================================================
import { state } from './state.js';
import { esc, toast } from './utils.js';
import { statusManutencao } from './manutencoes.js';

function badge(cor, texto) {
  return `<span class="badge badge-${cor}">${texto}</span>`;
}

function badgeEstoque(item) {
  if (item.estoque <= 0) return badge('red', 'Falta');
  if (item.estoque <= item.min_estoque) return badge('yellow', 'Repor');
  return badge('green', 'Ok');
}

function badgeManutencao(m) {
  const info = statusManutencao(m.validade);
  if (info.status === 'vencida') return badge('red', 'Vencida');
  if (info.status === 'vencendo') return badge('yellow', `Vence em ${info.diffDias}d`);
  return badge('green', 'No prazo');
}

function linhaVazia(cols, texto) {
  return `<tr><td colspan="${cols}" class="vazio">${texto}</td></tr>`;
}

function tabela(titulo, icone, cabecalhos, linhasHtml, colsVazio, textoVazio) {
  return `
    <section class="secao">
      <h2><i class="icone">${icone}</i> ${titulo}</h2>
      <table>
        <thead><tr>${cabecalhos.map(c => `<th>${c}</th>`).join('')}</tr></thead>
        <tbody>${linhasHtml || linhaVazia(colsVazio, textoVazio)}</tbody>
      </table>
    </section>`;
}

export function gerarRelatorioGeral() {
  const { dados } = state;
  if (!dados) { toast('Ainda carregando os dados. Aguarde um instante.'); return; }

  const agora = new Date();
  const dataGeracao = agora.toLocaleString('pt-BR');

  const linhasPecas = dados.pecas.map(p => `<tr>
      <td>#P-${p.id}</td><td>${esc(p.nome)}</td><td>${p.estoque} / ${p.min_estoque}</td><td>${badgeEstoque(p)}</td>
    </tr>`).join('');

  const linhasGuepar = dados.guepar.map(g => `<tr>
      <td>#G-${g.id}</td><td>${esc(g.nome)}</td><td>${g.estoque} / ${g.min_estoque}</td><td>${badgeEstoque(g)}</td>
    </tr>`).join('');

  const linhasForn = dados.fornecedores.map(f => `<tr>
      <td>#F-${f.id}</td><td>${esc(f.nome)}</td><td>${esc(f.cnpj) || '—'}</td><td>${esc(f.contato) || '—'}</td><td>${esc(f.telefone) || '—'}</td>
    </tr>`).join('');

  const manuOrdenadas = [...dados.manutencoes].sort((a, b) => a.validade.localeCompare(b.validade));
  const linhasManu = manuOrdenadas.map(m => `<tr>
      <td>${esc(m.nome)}</td><td class="capitalize">${esc(m.tipo)}</td><td>${m.validade.split('-').reverse().join('/')}</td><td>${badgeManutencao(m)}</td>
    </tr>`).join('');

  const pecasCriticas = dados.pecas.filter(p => p.estoque <= p.min_estoque).length;
  const gueparCriticos = dados.guepar.filter(g => g.estoque <= g.min_estoque).length;
  const manuVencidas = manuOrdenadas.filter(m => statusManutencao(m.validade).status === 'vencida').length;
  const manuVencendo = manuOrdenadas.filter(m => statusManutencao(m.validade).status === 'vencendo').length;

  const resumo = `
    <div class="resumo">
      <div class="resumo-item"><span class="resumo-valor">${dados.pecas.length}</span><span class="resumo-label">Peças do robô</span></div>
      <div class="resumo-item"><span class="resumo-valor">${dados.guepar.length}</span><span class="resumo-label">Materiais Guepar</span></div>
      <div class="resumo-item"><span class="resumo-valor">${dados.fornecedores.length}</span><span class="resumo-label">Fornecedores</span></div>
      <div class="resumo-item"><span class="resumo-valor">${dados.manutencoes.length}</span><span class="resumo-label">Manutenções</span></div>
      <div class="resumo-item alerta"><span class="resumo-valor">${pecasCriticas + gueparCriticos}</span><span class="resumo-label">Itens p/ repor</span></div>
      <div class="resumo-item alerta"><span class="resumo-valor">${manuVencidas + manuVencendo}</span><span class="resumo-label">Manut. vencidas/vencendo</span></div>
    </div>`;

  const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Relatório geral — Guepar vs Robô</title>
<style>
  :root { --accent:#0e7490; --bg:#f8fafc; --card:#ffffff; --line:#e2e8f0; --text:#0f172a; --muted:#64748b; }
  * { box-sizing: border-box; }
  body { font-family: -apple-system, Segoe UI, Roboto, Arial, sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 32px; }
  .topo { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 12px; }
  .topo h1 { margin: 0 0 4px 0; font-size: 24px; }
  .topo p { margin: 0; color: var(--muted); font-size: 13px; }
  .acoes { display:flex; gap: 8px; }
  .acoes button { border: 1px solid var(--line); background: var(--card); padding: 8px 14px; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; color: var(--text); }
  .acoes button.principal { background: var(--accent); color: #fff; border-color: var(--accent); }
  .resumo { display:grid; grid-template-columns: repeat(6, 1fr); gap: 12px; margin-bottom: 28px; }
  .resumo-item { background: var(--card); border: 1px solid var(--line); border-radius: 10px; padding: 14px; text-align:center; }
  .resumo-item.alerta { border-color: #f59e0b55; background: #fffbeb; }
  .resumo-valor { display:block; font-size: 22px; font-weight: 800; }
  .resumo-label { display:block; font-size: 11px; color: var(--muted); margin-top: 2px; }
  .secao { background: var(--card); border: 1px solid var(--line); border-radius: 12px; padding: 18px 20px; margin-bottom: 18px; }
  .secao h2 { font-size: 15px; margin: 0 0 12px 0; display:flex; align-items:center; gap:8px; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { text-align:left; color: var(--muted); font-weight: 700; padding: 8px 6px; border-bottom: 2px solid var(--line); }
  td { padding: 8px 6px; border-bottom: 1px solid var(--line); }
  tr:last-child td { border-bottom: none; }
  .capitalize { text-transform: capitalize; }
  .vazio { text-align:center; color: var(--muted); padding: 18px !important; }
  .badge { display:inline-block; padding: 2px 9px; border-radius: 999px; font-size: 11px; font-weight: 700; }
  .badge-red { background:#fee2e2; color:#b91c1c; }
  .badge-yellow { background:#fef3c7; color:#92400e; }
  .badge-green { background:#dcfce7; color:#15803d; }
  footer { text-align:center; color: var(--muted); font-size: 11px; margin-top: 20px; }
  @media print {
    body { padding: 12px; background: #fff; }
    .acoes { display: none; }
    .secao { break-inside: avoid; border: 1px solid #ddd; }
  }
</style>
</head>
<body>
  <div class="topo">
    <div>
      <h1>Relatório geral — Guepar vs Robô</h1>
      <p>Gerado em ${dataGeracao}</p>
    </div>
    <div class="acoes">
      <button class="principal" onclick="window.print()">Imprimir / Salvar em PDF</button>
      <button onclick="window.close()">Fechar aba</button>
    </div>
  </div>

  ${resumo}

  ${tabela('Manutenções', '🗓️', ['Nome', 'Tipo', 'Validade', 'Status'], linhasManu, 4, 'Nenhuma manutenção agendada.')}
  ${tabela('Guepar uso (materiais)', '🔧', ['Cód.', 'Nome', 'Qtd / mín.', 'Status'], linhasGuepar, 4, 'Nenhum material cadastrado.')}
  ${tabela('Peças do robô', '⚙️', ['Cód.', 'Nome', 'Qtd / mín.', 'Status'], linhasPecas, 4, 'Nenhuma peça cadastrada.')}
  ${tabela('Fornecedores', '👥', ['Cód.', 'Empresa', 'CNPJ', 'Contato', 'Telefone'], linhasForn, 5, 'Nenhum fornecedor cadastrado.')}

  <footer>Painel Guepar vs Robô · relatório gerado automaticamente a partir dos dados em tempo real do Supabase</footer>
</body>
</html>`;

  const janela = window.open('', '_blank');
  if (!janela) { toast('Seu navegador bloqueou o pop-up. Permita pop-ups para gerar o relatório.'); return; }
  janela.document.write(html);
  janela.document.close();
}
