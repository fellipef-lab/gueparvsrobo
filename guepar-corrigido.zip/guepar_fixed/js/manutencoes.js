// =====================================================================
// MANUTENÇÕES — controle de validade/revisão de peças e materiais.
// Segue o mesmo padrão de pecas.js / guepar.js / fornecedores.js:
// usa state.sb (o cliente já conectado), não o `supabase` global da CDN.
// =====================================================================
import { state } from './state.js';
import { $, esc, toast, confirmar, explicarErro } from './utils.js';

const TABELA = 'manutencoes';

// ---------- Regra de alerta por data ----------
function verificarAlerta(dataValidade) {
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0); // zera a hora para comparar só o dia

  const vencimento = new Date(dataValidade + 'T00:00:00'); // evita bug de fuso horário
  const diffDias = Math.ceil((vencimento - hoje) / (1000 * 60 * 60 * 24));

  if (diffDias < 0) return { cor: 'text-red-500', aviso: ' (Vencido!)' };
  if (diffDias <= 7) return { cor: 'text-yellow-400', aviso: ` (Vence em ${diffDias} dias)` };
  return { cor: 'text-green-500', aviso: ' (No prazo)' };
}

// ---------- Modal ----------
export function abrirModalManutencao() {
  $('modal-manutencao').classList.remove('hidden');
  $('modal-manutencao').classList.add('flex');
  $('manu-erro') && ($('manu-erro').textContent = '');
}

export function fecharModalManutencao() {
  $('modal-manutencao').classList.add('hidden');
  $('modal-manutencao').classList.remove('flex');
  $('manu-nome').value = '';
  $('manu-tipo').value = 'bateria';
  $('manu-validade').value = '';
}

// ---------- Render ----------
export async function carregarManutencoes() {
  const { data, error } = await state.sb.from(TABELA).select('*').order('validade', { ascending: true });
  if (error) { toast(explicarErro(error)); return; }

  const tbody = $('tabela-manutencoes');
  if (!tbody) return; // a aba pode não estar montada ainda

  tbody.innerHTML = data.length
    ? data.map(linha).join('')
    : '<tr><td colspan="4" class="p-8 text-center text-gray-400">Nenhuma manutenção agendada.</td></tr>';
}

function linha(item) {
  const alerta = verificarAlerta(item.validade);
  const dataFormatada = item.validade.split('-').reverse().join('/');
  return `<tr class="hover:bg-tech-900/40 transition-colors border-b border-gray-800">
    <td class="p-4 text-gray-200">${esc(item.nome)}</td>
    <td class="p-4 capitalize text-gray-400">${esc(item.tipo)}</td>
    <td class="p-4 font-bold ${alerta.cor}">${dataFormatada} <span class="text-xs font-normal">${alerta.aviso}</span></td>
    <td class="p-4 text-right">
      <button onclick="deletarManutencao(${item.id})" class="text-red-500 hover:text-red-400 p-2 rounded hover:bg-red-500/10 transition-colors">
        <i class="ph ph-trash text-xl"></i>
      </button>
    </td>
  </tr>`;
}

// ---------- Salvar ----------
export async function salvarManutencao() {
  const nome = $('manu-nome').value.trim();
  const tipo = $('manu-tipo').value;
  const validade = $('manu-validade').value;

  if (!nome || !validade) { toast('Preencha o nome e a data de validade.'); return; }

  const { error } = await state.sb.from(TABELA).insert([{ nome, tipo, validade }]);
  if (error) { toast(explicarErro(error)); return; }

  fecharModalManutencao();
  await carregarManutencoes();
  toast('Manutenção agendada.');
}

// ---------- Excluir ----------
export function deletarManutencao(id) {
  confirmar('Excluir este agendamento de manutenção?', async () => {
    const { error } = await state.sb.from(TABELA).delete().eq('id', id);
    if (error) { toast(explicarErro(error)); return; }
    await carregarManutencoes();
    toast('Agendamento excluído.');
  });
}
